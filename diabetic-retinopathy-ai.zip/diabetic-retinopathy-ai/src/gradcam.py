import numpy as np
from pytorch_grad_cam import GradCAM
from pytorch_grad_cam.utils.image import show_cam_on_image

from src.model import get_gradcam_target_layer
from src.transforms import val_transform


def generate_gradcam(model, image, target_layer=None):
    """
    image: a preprocessed RGB numpy array in [0, 255] uint8,
           e.g. the output of src.preprocessing.load_image()
    """
    if target_layer is None:
        target_layer = get_gradcam_target_layer(model)

    input_tensor = val_transform(image).unsqueeze(0)
    device = next(model.parameters()).device
    input_tensor = input_tensor.to(device)

    cam = GradCAM(model=model, target_layers=[target_layer])
    grayscale_cam = cam(input_tensor=input_tensor)[0]

    rgb_image = image.astype("float32") / 255.0
    visualization = show_cam_on_image(rgb_image, grayscale_cam, use_rgb=True)

    return visualization
